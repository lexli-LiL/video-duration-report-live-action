#!/usr/bin/env python3
"""
Video Duration Report Tool
Reads a source video CSV, consolidates files by video identity,
and writes a clean report CSV with accumulated durations and flags.
"""

import csv
import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox
from collections import OrderedDict


# ---------------------------------------------------------------------------
# Duration helpers
# ---------------------------------------------------------------------------

def parse_duration(s):
    """Convert 'H:MM:SS' or 'MM:SS' string to total seconds (int)."""
    s = s.strip()
    if not s:
        return 0
    parts = s.split(':')
    try:
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
        elif len(parts) == 2:
            return int(parts[0]) * 60 + int(parts[1])
    except ValueError:
        pass
    return 0


def format_duration(seconds):
    """Convert total seconds to 'H:MM:SS' string."""
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h}:{m:02d}:{s:02d}"


# ---------------------------------------------------------------------------
# Filename parser
# ---------------------------------------------------------------------------

def parse_filename(filename):
    """
    Parse a video filename into its components.

    Expected pattern (split on '_'):
      courseID  locale1  locale2  ch  lesson  descriptor  take  cam  [location]  VT

    Examples:
      4681000_EN_US_02_03_Champion_02_B_VT
      4681000_en_US_00_01_Intro_01_A_LA_VT
      4681000_en_US_XX_XX_FalseTake_01_A_LA_VT

    Returns a dict or None if the filename cannot be parsed.
    """
    name = filename.strip()
    parts = name.split('_')

    # Need at least: courseID locale1 locale2 ch lesson descriptor take cam VT = 9 parts
    if len(parts) < 9:
        return None

    course_id  = parts[0]
    chapter    = parts[3].upper()
    lesson     = parts[4].upper()
    descriptor = parts[5]
    take       = parts[6]   # '01', '02', 'PU', etc.
    cam        = parts[7]   # 'A' or 'B'

    std_name = f"{course_id}_EN_US_{chapter}_{lesson}_{descriptor}_VT"
    group_key = (course_id, chapter, lesson, descriptor.lower())

    return {
        'course_id':  course_id,
        'chapter':    chapter,
        'lesson':     lesson,
        'descriptor': descriptor,
        'take':       take,
        'cam':        cam,
        'std_name':   std_name,
        'group_key':  group_key,
    }


# ---------------------------------------------------------------------------
# Core processing
# ---------------------------------------------------------------------------

def process_csv(input_path):
    """
    Read the source CSV, consolidate rows by video identity, and write the
    report CSV.  Returns the path of the saved output file.
    """
    # --- Read source ---
    with open(input_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        source_rows = [row for row in reader if row.get('Filename', '').strip()]

    if not source_rows:
        raise ValueError("No data rows found in the source CSV.")

    # --- Group by video identity ---
    groups = OrderedDict()   # group_key → {'info': ..., 'files': [...]}

    for row in source_rows:
        info = parse_filename(row['Filename'])
        if info is None:
            # Skip rows that don't match the expected pattern
            continue
        key = info['group_key']
        if key not in groups:
            groups[key] = {'info': info, 'files': []}
        groups[key]['files'].append((row, info))

    if not groups:
        raise ValueError("No filenames matched the expected naming pattern.")

    # --- Build output rows ---
    output_rows = []
    current_chapter = None

    grand_total_seconds = 0

    for key, group in groups.items():
        chapter = key[1]

        # Skip XX/xx utility clips (FalseTake, RoomTone, TechCheck, etc.)
        if chapter == 'XX':
            continue

        # Insert a blank separator row when the chapter changes
        if current_chapter is not None and chapter != current_chapter:
            output_rows.append(None)
        current_chapter = chapter

        files = group['files']
        info  = group['info']

        # Sum all durations in this group
        total_seconds = sum(parse_duration(row.get('Duration', '0')) for row, _ in files)
        grand_total_seconds += total_seconds

        # Collect take numbers and cams
        takes = [fi['take'].upper() for _, fi in files]
        cams  = [fi['cam'].upper()  for _, fi in files]

        # --- Flags ---
        # Retake: any take number ≥ 2
        retake_nums = sorted(set(int(t) for t in takes if t.isdigit() and int(t) >= 2))
        retake_val  = ('TK' + ','.join(str(n) for n in retake_nums)) if retake_nums else ''

        # Pickup: take field is literally 'PU'
        has_pickup = any(t == 'PU' for t in takes)

        # A/B cam: group has both A and B
        has_ab_cam = 'A' in cams and 'B' in cams

        output_rows.append({
            'Filename':   info['std_name'],
            'Duration':   format_duration(total_seconds),
            'Retake(s)':  retake_val,
            'Pickup':     'X' if has_pickup else '',
            'A/B Cam':    'X' if has_ab_cam else '',
        })

    # --- Append blank separator + total row ---
    output_rows.append(None)
    output_rows.append({
        'Filename':  'TOTAL',
        'Duration':  format_duration(grand_total_seconds),
        'Retake(s)': '',
        'Pickup':    '',
        'A/B Cam':   '',
    })

    # --- Determine output path ---
    course_id  = next(iter(groups))[0]
    output_dir = os.path.dirname(input_path)
    output_path = os.path.join(output_dir, f"Final duration doc_{course_id}.csv")

    # --- Write output CSV ---
    fieldnames = ['Filename', 'Duration', 'Retake(s)', 'Pickup', 'A/B Cam']
    empty_row  = {k: '' for k in fieldnames}

    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in output_rows:
            writer.writerow(row if row is not None else empty_row)

    return output_path


# ---------------------------------------------------------------------------
# GUI entry point
# ---------------------------------------------------------------------------

def main():
    root = tk.Tk()
    root.withdraw()          # hide the empty root window
    root.attributes('-topmost', True)

    input_path = filedialog.askopenfilename(
        title="Select source video CSV",
        filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
    )

    if not input_path:
        return   # user cancelled

    try:
        output_path = process_csv(input_path)
        messagebox.showinfo(
            "Done",
            f"Report saved to:\n{output_path}",
            parent=root,
        )
    except Exception as exc:
        messagebox.showerror(
            "Error",
            f"Could not process the file:\n\n{exc}",
            parent=root,
        )


if __name__ == '__main__':
    main()
